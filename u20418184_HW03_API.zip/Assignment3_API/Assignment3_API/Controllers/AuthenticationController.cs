﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment3_API.Models;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.DependencyInjection;
using Assignment3_API.Factory;
using MimeKit;
using MimeKit.Text;
using MailKit.Net.Smtp;
using MailKit.Security;


namespace Assignment3_API.Controllers
{
    

    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IEmailService _emailService;

        public AuthenticationController(AppDbContext appDbContext, IEmailService emailService)
        {
            _context = appDbContext;
            _emailService = emailService;
        }

 
//Get all registered users
        [HttpGet("users")]
        public IActionResult GetRegistered()
        {
            var userDetails = _context.Registers.AsQueryable();
             return Ok(userDetails);
        }


        [HttpPost("register")]
        public IActionResult Register([FromBody] Register userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
            else
            {
                userObj.Password = PasswordSecurity.EncriptPassword(userObj.Password);

                _context.Registers.Add(userObj);
                _context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "Registered successfully."
                });
            }
            //if (_context.Registers.Any(u => u.Email== Request.Email))
            //{
            //    return BadRequest("User already exists.");
            //}
        }

        //send email with otp still under construction, kind of working on the API
        [HttpPost("sendEmail")]
        public IActionResult SendEmail(EmailSettings request)
        {
            _emailService.SendEmail(request);
            return Ok();
        }


        //Login
        [HttpPost("login")]
        public IActionResult Login([FromBody] Register userObj)
        {
            if (userObj == null)
            {
                return BadRequest();
            }
            else
            {
                var registeredUser = _context.Registers.Where(a => a.Email == userObj.Email).FirstOrDefault();
                //var user = _context.Registers.Where(a =>
                // a.Email == userObj.Email
                // && a.Password == userObj.Password).FirstOrDefault();
                if (registeredUser != null && PasswordSecurity.DecriptPassword(registeredUser.Password)==userObj.Password)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = "Logged in successfully, OTP has been sent to your email address.",
                        UserData = userObj.Email
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "“Invalid user credentials or does not exist.",
                        UserData= userObj.Email
                    });
                }
            }
        }

       




    }
}
