﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Assignment3_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Assignment3_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
         private readonly AppDbContext _db= new AppDbContext();

        [HttpGet ("products")]
        public object GetProduct()
        {
            try
            {
                var Products= _db.Products.ToList();
                return Products;
            }
            catch(Exception message)
            {
                return message;
            }
        }

        [HttpGet ("GetDashboard")]
        public IQueryable<object> GetDashboard()
        {

            var query = from p in _db.Products
                        join b in _db.Brands on p.Brand.BrandId equals b.BrandId
                        join pt in _db.ProductTypes on p.ProductType.ProductTypeId equals pt.ProductTypeId
                        orderby p.Price descending
                        select new
                        {

                            p1 = p.Name,
                            p2 = p.Price,
                            p3 = b.Name,
                            p4 = pt.Name,
                            p5 = p.Description
                        };
                       
            var result = query.ToList();
            return query.Take(10);
        }

        [HttpGet("brands")]
        public object GetBrands()
        {
            return _db.Brands;
        }

        //[HttpGet("brands")]
        //public IActionResult GetBrands()
        //{
        //    var results = _db.Brands.GroupBy(
        //        p => p.Name,
        //        (key) => new { Name = key });
        //    return Ok(results);
        //}

        [HttpGet("productType")]
        public object GetProductType()
        {
            try
            {
                var ProductType = _db.ProductTypes.ToList();
                return ProductType;
            }
            catch (Exception message)
            {
                return message;
            }
        }



    }
}

