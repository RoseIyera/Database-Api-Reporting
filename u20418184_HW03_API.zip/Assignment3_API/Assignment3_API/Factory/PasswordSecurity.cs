﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3_API.Factory
{
    public class PasswordSecurity
    {
        public static string secretKey = "@GotASecreteCanYouKeepIt";
        public static string EncriptPassword(string password)
        {
            if(string.IsNullOrEmpty(password))
            {
                return " ";
            }
            else
            {
                password = password + secretKey;
                var passwordinBytes = Encoding.UTF8.GetBytes(password);
                return Convert.ToBase64String(passwordinBytes);
            }
        }

        public static string DecriptPassword(string encriptedPassword)
        {
            if (string.IsNullOrEmpty(encriptedPassword))
            {
                return " ";
            }
            else
            {
                var encodedBytes = Convert.FromBase64String(encriptedPassword);
                var realPassword = Encoding.UTF8.GetString(encodedBytes);
                realPassword = realPassword.Substring(0, realPassword.Length - secretKey.Length);
                return realPassword;
            }
        }
    }
}
