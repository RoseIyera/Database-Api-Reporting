﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment3_API.Models;
using MimeKit;

namespace Assignment3_API.Factory
{
    public interface IEmailService
    {
        //bool SendEmail(MimeMessage emailData);
        void SendEmail(EmailSettings request);
    }
}
