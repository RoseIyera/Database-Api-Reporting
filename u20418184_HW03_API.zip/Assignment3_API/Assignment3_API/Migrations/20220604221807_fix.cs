﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Assignment3_API.Migrations
{
    public partial class fix : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Registers",
                table: "Registers");

            migrationBuilder.RenameTable(
                name: "Registers",
                newName: "registeredUser");

            migrationBuilder.AddPrimaryKey(
                name: "PK_registeredUser",
                table: "registeredUser",
                column: "ID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_registeredUser",
                table: "registeredUser");

            migrationBuilder.RenameTable(
                name: "registeredUser",
                newName: "Registers");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Registers",
                table: "Registers",
                column: "ID");
        }
    }
}
